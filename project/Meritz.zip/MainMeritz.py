from Main.MainController import MainController as mc
if __name__ == "__main__":
    mainObj = mc()
    mainObj.run()