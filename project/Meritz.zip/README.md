- example 코드 -
meritz.py : python meritz.py 연도입력
=> example 코드는 csv파일을 읽는 방식이 아닌, Common Folder에 저장된 생명표 List를 읽어서 처리합니다.
ex) python meritz.py 5

- program 코드 -
MainMeritz.py : python MainMeritz.py -year 연도입력
=> program 코드는 csv파일을 읽는 방식으로 처리하였고, DATA Folder에 저장된 생명표 CSV파일을 읽어서 처리합니다.
추가적으로 10이상의 값은 처리되지 않습니다.
ex) python MainMeritz.py -year 5

