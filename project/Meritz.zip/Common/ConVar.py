# 보험금 : 1억
insurance_price = 100000000

# 가입기간
# 변수로서 받아야함
subscription_period = 1

# 연이율
annual_interest_rate = 1.05

# 생명표 리스트
qx_list = [
    0.0027, 
    0.003, 
    0.00335, 
    0.0034,
    0.00345,
    0.00350,
    0.00350,
    0.00355,
    0.00400,
    0.00450,
    0.00450
    ]

# CSV 파일 위치
CSV_PATH = 'DATA/qx.csv'